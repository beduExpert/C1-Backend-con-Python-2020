from django.apps import AppConfig


class ServiciosConfig(AppConfig):
    name = 'servicios'
