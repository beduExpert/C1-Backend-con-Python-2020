from django.apps import AppConfig


class TarjetaConfig(AppConfig):
    name = 'tarjeta'
